Frutiger Astro - Setup
======================

1. Unzip this.

2. Rename FrutigerAstro.ex_ to FrutigerAstro.exe
   (can't see the .ex_ part? File Explorer > View > Show > File name extensions)

3. Turn off Smart App Control.
   (Windows Security > App & browser control > Smart App Control settings > Off)
   The EXE isn't code-signed, so Windows won't run it otherwise.

4. Put FrutigerAstro.exe in a folder you can write to (Desktop, Documents,
   a USB stick - not Program Files) and run it.

5. That's the only manual install. When a new version is out, the light on the
   Update tab turns amber: press Install update and it restarts into the new one.

Made by DOOG unincorporated.
